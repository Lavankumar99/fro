import React from 'react';
import { Link } from 'react-router-dom';
import { axiosAddToCart } from '../Service-Components/ServiceCart';
import { Container, Typography, Box, FormGroup, Button } from '@material-ui/core';
import { toast } from 'react-toastify';
import { useHistory,useParams } from 'react-router-dom';
toast.configure();
const notifysuccess = (msg) => {
    toast.success(msg, {
        position: 'top-center',
        autoClose: 2000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: false,
        progress: undefined,
        theme: 'colored'
    });
}
const myComponent = {
    width: '550px',
    height: '150px',
    overflowX: 'hidden',
    overflowY: 'hidden',
    top: '100px',
    left: '350px'
};


const AddCartAlreadyItem = () => {
    const history = useHistory();
    const { id } = useParams();
    const addToCartConfirm = async () => {

        let custid = sessionStorage.getItem('id');
        await axiosAddToCart(custid, id);
        notifysuccess("Product added to cart successfully")
        history.push('/cart');



    }
    return (
        <div className='add-product-form' style={myComponent}>
            <Container maxWidth="sm">
                <Box my={5}>
                    <Typography variant="h5" align="center"><b>Product Already Present in your Cart</b></Typography>
                    <FormGroup>
                        <Box my={3}>
                            <Button variant="text" onClick={() => addToCartConfirm()} color="primary" align="center">Proceed Anyway</Button>
                            <Button component={Link} to={`/viewproducts`} variant="text" color="secondary" align="center" style={{ margin: '0px 20px' }}>Cancel</Button>
                        </Box>
                    </FormGroup>
                </Box>
            </Container>
        </div>
    )
}

export default AddCartAlreadyItem;
